'use strict';
const {contextBridge,ipcRenderer} = require('electron');
contextBridge.exposeInMainWorld('stalkerDesktop',Object.freeze({
  saveImage: bytes => ipcRenderer.invoke('assets:save',bytes),
  startServer: config => ipcRenderer.invoke('server:start',config),
  stopServer: () => ipcRenderer.invoke('server:stop'),
  appVersion: () => ipcRenderer.invoke('app:version'),
  onNavigate: callback => { if(typeof callback!=='function')return; ipcRenderer.on('app:navigate',(_event,payload)=>callback(payload)); },
  chooseImage: () => ipcRenderer.invoke('assets:choose'),
  readSavedData: () => ipcRenderer.invoke('data:read'),
  writeSavedData: data => ipcRenderer.invoke('data:write',data)
}));
