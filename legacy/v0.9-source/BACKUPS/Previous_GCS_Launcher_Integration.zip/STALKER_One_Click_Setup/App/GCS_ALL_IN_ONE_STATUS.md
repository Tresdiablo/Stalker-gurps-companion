# GCS + STALKER desktop integration — initial working bridge

## Included and verified
- One STALKER Electron desktop entry point with a `GCS` native application menu.
- Full original GCS editor can be started from STALKER (no reduced imitation editor).
- The editor's own windows, character creation, Master/User Library interfaces and calculation engine remain those of GCS.
- Optional `gcs.exe` selection if installed outside standard `Program Files/GCS` or local Programs folder.
- GCS character file picker in STALKER Character Sheet; imports through the **existing** STALKER importer, preserving its original save behavior.
- No deletion of original GCS character documents, libraries, or STALKER campaign saves.

## Important limitations
- This is **not** yet a single-window merged executable. GCS uses native Unison UI; the companion uses Electron. The app launches GCS as its own native window. True in-window merging would require substantial upstream GCS UI work or a complete rewrite of the GCS interface; it is not accomplished in this package.
- You must install GCS from the official site separately or provide an existing `gcs.exe`. No GCS binary or library data is bundled.
- Character synchronization is **manual and one-way** at present: after editing and saving in GCS, use **Import character from GCS** to refresh the STALKER profile. Changes made in STALKER do not write back to the .gcs file.
- GCS calculations and the STALKER app's existing imported-stat calculations are not yet guaranteed to match. Review imported values.
- On Windows, installation/build validation and real native GCS launch remain untested in this Linux build environment. JavaScript syntax and existing backend test suite can be checked here.
- The GCS controls are available only in the installed Electron desktop app, not the browser-only preview.

## How to use
1. Back up existing character and campaign data.
2. Install the original GCS from https://gurpscharactersheet.com/ (Windows).
3. Build/launch STALKER using the existing `INSTALL_WINDOWS.cmd` process.
4. Open **Character Sheet** and select **Open GCS**. If GCS is not found, select **Locate gcs.exe**.
5. Edit/create your character in the native GCS window and save it as `.gcs`.
6. In STALKER select **Import character from GCS** to bring the saved character into the active STALKER character profile.

## Sources
- https://github.com/richardwilkes/gcs — upstream GCS repository (MPL-2.0; native Unison UI)
- https://gurpscharactersheet.com/ — upstream Windows installer
- https://gurpscharactersheet.com/faq.html — original GCS settings/CLI behavior
- User-supplied STALKER GURPS Build 4.5 Integrated Beta 0.8 / Desktop Controls Cleanup source code.
