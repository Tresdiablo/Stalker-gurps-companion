'use strict';
const {contextBridge,ipcRenderer} = require('electron');
contextBridge.exposeInMainWorld('stalkerDesktop',Object.freeze({
  gcsStatus: () => ipcRenderer.invoke('gcs:status'),
  gcsConfigure: () => ipcRenderer.invoke('gcs:configure'),
  gcsOpen: () => ipcRenderer.invoke('gcs:open'),
  gcsChooseCharacter: () => ipcRenderer.invoke('gcs:choose-character'),
  gcsEditCharacter: path => ipcRenderer.invoke('gcs:edit-character',path),
  onGcsImport: callback => {if(typeof callback==='function')ipcRenderer.on('gcs:import-character',(_event,payload)=>callback(payload));},
  saveImage: bytes => ipcRenderer.invoke('assets:save',bytes),
  startServer: config => ipcRenderer.invoke('server:start',config),
  stopServer: () => ipcRenderer.invoke('server:stop'),
  appVersion: () => ipcRenderer.invoke('app:version'),
  onNavigate: callback => { if(typeof callback!=='function')return; ipcRenderer.on('app:navigate',(_event,payload)=>callback(payload)); },
  chooseImage: () => ipcRenderer.invoke('assets:choose'),
  readSavedData: () => ipcRenderer.invoke('data:read'),
  writeSavedData: data => ipcRenderer.invoke('data:write',data)
}));
