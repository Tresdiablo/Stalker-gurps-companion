/* GCS desktop integration - full upstream GCS opens in its native window.
   Existing STALKER character import is kept authoritative for game stats. */
(()=>{
 'use strict';
 const bridge=window.stalkerDesktop;
 const sheet=document.getElementById('sheetPage');
 if(!bridge||!sheet)return;
 const block=document.createElement('section');block.className='panel gcs-native-panel';
 block.innerHTML='<h2>FULL GCS CHARACTER EDITOR</h2><p class="page-help">Launch the complete native GURPS Character Sheet application with its character creator, libraries and documents. Import a saved .gcs file to update this STALKER character; your original GCS file stays unchanged.</p><div class="gcs-native-actions"><button id="gcsNativeLaunch" type="button">Open GCS</button><button id="gcsNativeImport" type="button">Import character from GCS</button><button id="gcsNativeConfigure" type="button">Locate gcs.exe</button></div><p class="hint" id="gcsNativeStatus" aria-live="polite">Checking installation…</p>';
 sheet.insertBefore(block,sheet.querySelector('.panel'));
 const status=block.querySelector('#gcsNativeStatus');
 let lastFile=null;
 async function updateStatus(){try{const r=await bridge.gcsStatus();status.textContent=r.available?'Full GCS available: '+r.path:'GCS not found. Install GCS and select gcs.exe using Locate gcs.exe.';}catch(e){status.textContent=String(e.message||e)}}
 function importPayload(payload){
  if(!payload)return;
  try{
   const f=new File([payload.content],payload.name,{type:'application/json'});
   const input=document.getElementById('gcsFile');
   if(!input)throw Error('STALKER character import is unavailable.');
   // Existing import handler performs validation, stat update and save.
   const transfer=new DataTransfer();transfer.items.add(f);input.files=transfer.files;
   lastFile=payload.path;
   input.dispatchEvent(new Event('change',{bubbles:true}));
   status.textContent='Imported '+payload.name+'. Save edits in GCS and re-import to update.';
  }catch(err){status.textContent='Import error: '+err.message;}
 }
 block.querySelector('#gcsNativeLaunch').onclick=async()=>{const r=await bridge.gcsOpen();if(r.error)status.textContent=r.error;else status.textContent='GCS launched. Use its native window for full editing.';};
 block.querySelector('#gcsNativeConfigure').onclick=async()=>{try{await bridge.gcsConfigure();await updateStatus()}catch(err){status.textContent=err.message}};
 block.querySelector('#gcsNativeImport').onclick=async()=>{try{importPayload(await bridge.gcsChooseCharacter())}catch(err){status.textContent=err.message}};
 bridge.onGcsImport(importPayload);
 updateStatus();
})();
